/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "livekit/data_track_error.h"
#include "livekit/data_track_frame.h"
#include "livekit/data_track_info.h"
#include "livekit/ffi_handle.h"
#include "livekit/result.h"
#include "livekit/visibility.h"

namespace livekit {

namespace proto {
class OwnedLocalDataTrack;
}

/// Represents a locally published data track.
///
/// Unlike audio/video tracks, data tracks do not extend the Track base class.
/// They use a separate publish/unpublish lifecycle and carry arbitrary binary
/// frames instead of media.
///
/// Created via LocalParticipant::publishDataTrack().
///
/// Typical usage:
///
///   auto lp = room->localParticipant().lock();
///   if (!lp) return; // room not connected or already torn down
///   auto result = lp->publishDataTrack("sensor-data");
///   if (result) {
///     auto dt = result.value();
///     DataTrackFrame frame;
///     frame.payload = {0x01, 0x02, 0x03};
///     (void)dt->tryPush(frame);
///     dt->unpublishDataTrack();
///   }
class LIVEKIT_API LocalDataTrack {
public:
  ~LocalDataTrack() = default;

  LocalDataTrack(const LocalDataTrack&) = delete;
  LocalDataTrack& operator=(const LocalDataTrack&) = delete;

  /// Metadata about this data track.
  const DataTrackInfo& info() const noexcept { return info_; }

  /// Try to push a frame to all subscribers of this track.
  ///
  /// An empty payload succeeds without sending a frame to subscribers.
  ///
  /// @param frame The frame to push.
  /// @return Success on delivery acceptance, or a typed error describing why
  ///         the frame could not be queued.
  Result<void, LocalDataTrackTryPushError> tryPush(const DataTrackFrame& frame);

  /// Try to push a frame to all subscribers of this track.
  ///
  /// An empty payload succeeds without sending a frame to subscribers.
  ///
  /// @param payload The payload to push.
  /// @param user_timestamp Optional application-defined timestamp. The unit is
  ///        caller-defined.
  /// @return Success on delivery acceptance, or a typed error describing why
  ///         the frame could not be queued.
  Result<void, LocalDataTrackTryPushError> tryPush(std::vector<std::uint8_t>&& payload,
                                                   std::optional<std::uint64_t> user_timestamp = std::nullopt);

  /// Try to push a frame from a borrowed byte buffer.
  ///
  /// Copies @p size bytes from @p data into an FFI request before returning;
  /// the SDK does not retain the buffer.
  /// An empty payload succeeds without sending a frame to subscribers.
  ///
  /// @note This avoids an intermediate copy when the caller already owns a byte
  /// buffer, but it is not a zero-copy send.
  ///
  /// @param data Pointer to @p size payload bytes. Must be non-null when
  ///        @p size is non-zero.
  /// @param size Number of bytes at @p data. A value of zero is a successful
  ///        no-op.
  /// @param user_timestamp Optional application-defined timestamp. The unit is
  ///        caller-defined.
  /// @return Success on delivery acceptance, or a typed error describing why
  ///         the frame could not be queued.
  Result<void, LocalDataTrackTryPushError> tryPush(const std::uint8_t* data, std::size_t size,
                                                   std::optional<std::uint64_t> user_timestamp = std::nullopt);

  /// Whether the track is still published in the room.
  bool isPublished() const;

  /// Unpublish this data track from the room.
  ///
  /// After this call, tryPush() fails and the track cannot be re-published.
  void unpublishDataTrack();

private:
  friend class LocalParticipant;

  explicit LocalDataTrack(const proto::OwnedLocalDataTrack& owned);

  uintptr_t ffiHandleId() const noexcept { return handle_.get(); }

  /// RAII wrapper for the Rust-owned FFI resource.
  FfiHandle handle_;

  /// Metadata snapshot taken at construction time.
  DataTrackInfo info_;
};

} // namespace livekit
